package org.com;

public interface Software {
	void softwareResources();
}
