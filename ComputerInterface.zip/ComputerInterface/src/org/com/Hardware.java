package org.com;

public interface Hardware {
	void hardwareResources();
}
