package org.acc.test.scanner;

import java.util.Scanner;

public class StudentDetails {
	private void average() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Mark1");
		short mark1 = sc.nextShort();

		System.out.println("Enter Mark2");
		short mark2 = sc.nextShort();

		System.out.println("Enter Mark3");
		short mark3 = sc.nextShort();

		System.out.println("Enter Mark4");
		short mark4 = sc.nextShort();

		System.out.println("Enter Mark5");
		short mark5 = sc.nextShort();

		float avg = ((mark1 + mark2 + mark3 + mark4 + mark5) / 5);
		System.out.println("Average mark:" + avg);

	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Student Id");
		short id = sc.nextShort();
		System.out.println("Student ID:"+id);
		
		System.out.println("Enter Student Name");
		String name = sc.next();
		System.out.println("Student Name:"+name);
		
		StudentDetails avg = new StudentDetails();
		avg.average();

	}
}
