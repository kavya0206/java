package org.edu;

public class Education {
	public void ug() {
		System.out.println("Ug courses");
	}

	public void pg() {
		System.out.println("Pg courses");
	}
}
