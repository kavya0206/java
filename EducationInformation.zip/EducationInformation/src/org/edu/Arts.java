package org.edu;

public class Arts extends Engineering{
	public void bsc() {
		System.out.println("BSC");
	}

	public void bEd() {
		System.out.println("B.Ed");
	}

	public void ba() {
		System.out.println("BA");
	}

	public void bBa() {
		System.out.println("BBA");
	}
}
