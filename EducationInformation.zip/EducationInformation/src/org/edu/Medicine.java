package org.edu;

public class Medicine {
	public void physio() {
		System.out.println("Physio");
	}

	public void dental() {
		System.out.println("Dental");
	}

	public void mbbs() {
		System.out.println("MBBS");
	}
}
