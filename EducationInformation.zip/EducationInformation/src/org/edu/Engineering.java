package org.edu;

public class Engineering extends Medicine{
	public void be() {
		System.out.println("BE");
	}

	public void bTech() {
		System.out.println("BTech");
	}
}
