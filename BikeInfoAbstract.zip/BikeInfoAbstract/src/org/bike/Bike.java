package org.bike;

public abstract class Bike {
	public abstract void cost();

	public abstract void speed();
}
