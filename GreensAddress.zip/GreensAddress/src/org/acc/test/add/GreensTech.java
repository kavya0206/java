package org.acc.test.add;

public class GreensTech {
	// method creation
	private void greensOmr() {
		System.out.println("Omr Address:\nGreensTechnologys\nOMR\n");
	}

	private void greensAdayar() {
		System.out.println("Adayar Address:\nGreensTechnologys\nAdayar\n");
	}

	private void greensTambaram() {
		System.out.println("Tambaram Address:\nGreensTechnologys\nTamabram\n");
	}

	private void greensVelachery() {
		System.out.println("Velachery Address:\nGreensTechnologys\nVelachery\n");
	}

	private void greensAnnaNagar() {
		System.out.println("AnnaNagar Address:\nGreensTechonologys\nAnnaNagar");
	}

	// main method
	public static void main(String[] args) {
		// object creation
		GreensTech add = new GreensTech();
		// method call
		add.greensOmr();
		add.greensAdayar();
		add.greensTambaram();
		add.greensVelachery();
		add.greensAnnaNagar();
	}
}
