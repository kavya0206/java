package org.univ;

public abstract class University {
	public abstract void ug();

	public abstract void pg();
}
